Reaction Helper — Android

This project intentionally does NOT automatically send bulk Facebook friend requests.
It opens the supplied Facebook post and keeps the selected reaction/limit visible as a workflow guide.

Build:
- Android Studio: open this folder and build the debug APK.
- Or GitHub Actions: push the folder to a repository; the included workflow builds app-debug.apk.

Why no auto-request:
Facebook UI/permissions change frequently, and automated bulk friend requests can trigger account restrictions. This helper keeps the final request action manual.
