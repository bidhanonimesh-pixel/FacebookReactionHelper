package com.example.reactionhelper

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.*
import android.app.Activity

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val url = findViewById<EditText>(R.id.postUrl)
        val spinner = findViewById<Spinner>(R.id.reactionSpinner)
        val limit = findViewById<EditText>(R.id.limitInput)
        val status = findViewById<TextView>(R.id.status)

        spinner.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            arrayOf("❤️ Love", "👍 Like")
        )

        findViewById<Button>(R.id.openPost).setOnClickListener {
            val s = url.text.toString().trim()
            if (!s.startsWith("http://") && !s.startsWith("https://")) {
                url.error = "সঠিক Facebook post link দিন"
                return@setOnClickListener
            }
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(s)))
            status.text = "Post খোলা হয়েছে। Facebook-এ reaction list খুলুন।"
        }

        findViewById<Button>(R.id.openGuide).setOnClickListener {
            val type = spinner.selectedItem.toString()
            val n = limit.text.toString().toIntOrNull() ?: 50
            status.text = "Target: $type • প্রথম $n জন।\n\nFacebook-এ reaction count/লিস্টে tap করুন → $type filter করুন → যাদের Add Friend আছে তাদের profile খুলে তুমি নিজে Request পাঠাও।"
        }
    }
}
